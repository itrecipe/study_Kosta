package com.market.exception;

public class CartException extends Exception{
	
	  
	public CartException(String str)
	{
		super(str);
	}  
  
}
