public class Example02 {
   public static String greeting( ) {    
          return "Hi!";
   }
   public static void main(String[] args) {   
      String str = greeting(); 
      System.out.println(str + " Java");            
   }
}