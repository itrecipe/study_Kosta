public class Example03 {
   public static int add(int x, int y) {      
      return x + y;
   } 

   public static void main(String[] args) {   
      int a= 5, b = 6;
      int sum = add(a,b); 
      System.out.println(a +"(��)�� "+ b +"�� ���� "+ sum +"�Դϴ�.");
           
   }
}