public class Example05 {
   public static void add(int x, int y) {        
      System.out.println(x +"(��)�� "+ y +"�� ���� "+ (x + y) + "�Դϴ�.");
   }
   public static void main(String[] args) {   
      int a = 5, b = 6;
      add(a,b);  
   }
}