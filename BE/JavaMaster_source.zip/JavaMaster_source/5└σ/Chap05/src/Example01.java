public class Example01 {
   public static void  method() {  
      System.out.println("static �޼����Դϴ�.");
      System.out.println(5 + 6);
   }  
   public static void main(String[] args) {          
       method();       
   }
}