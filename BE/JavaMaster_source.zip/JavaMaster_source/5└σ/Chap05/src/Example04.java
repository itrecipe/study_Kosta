public class Example04 {
   public static void print( ) {     
      System.out.println("Hi! Java");
   } 

   public static void main(String[] args) {         
      print();          
   }
}