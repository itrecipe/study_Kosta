public class Constructor01 {
    public static void main(String[] args) {  
		
        System.out.println("****�л� �ּҷ�****");
        Student stObj = new Student();  
		
        stObj.insertRecord(20221004, "ȫ���");		
        stObj.printInfo();
    }	
}