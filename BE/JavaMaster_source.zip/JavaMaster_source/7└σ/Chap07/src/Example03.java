public class Example03 {
    public static void main(String[] args) {  
 
        Cat catObj = new Cat();		
		
        System.out.println("�丣�þ� ������");
        catObj.meow();  	    
    }
}