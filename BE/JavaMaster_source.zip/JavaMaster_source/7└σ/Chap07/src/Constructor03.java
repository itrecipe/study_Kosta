public class Constructor03 {
    public static void main(String[] args) {  
		
        Add numObj1 = new Add(1, 2);		
	
        Add numObj2 = new Add(2.4, 6.2);		
		
        Add numObj3 = new Add(3, 5.5);			
    }	
}