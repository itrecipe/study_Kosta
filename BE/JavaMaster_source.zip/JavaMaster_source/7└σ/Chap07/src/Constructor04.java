public class Constructor04 {
    public static void main(String[] args) {  
		
        MemberChain object = new MemberChain();
        object.printInfo();		
    }	
}