public class Example07 {
    public static void main(String[] args) {  
		
        Chain obj = new Chain();	
		
    }	
}