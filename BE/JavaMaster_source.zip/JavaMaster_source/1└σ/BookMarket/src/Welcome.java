public class Welcome {
	public static void main(String[] args) {

		System.out.println("Welcome to Shopping Mall"); 
		System.out.println("Welcome to Book Market!"); 

	}
}