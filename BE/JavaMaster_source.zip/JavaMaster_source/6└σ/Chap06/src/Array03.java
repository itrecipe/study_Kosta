import java.util.Scanner;

public class Array03 {
	public static void main(String[] args) {
		double[][] marks = new double[2][3];
		Scanner s = new Scanner(System.in);

		for (int i = 0; i < 2; i++) {
			System.out.println("�л���ȣ" + (i + 1));	
			System.out.print("�������� : " );
			marks[i][0] = s.nextDouble();

			System.out.print("�������� : " );
			marks[i][1] = s.nextDouble();	 

			marks[i][2] = (marks[i][0] + marks[i][1])/2;   
	    	}	 
		 
		for (int i = 0; i < 2; i++) {
	        		System.out.println("�л���ȣ" + (i + 1)); 
 			System.out.print("����" + ":" + marks[i][0] + " ");
			System.out.print("����" + ":" + marks[i][1] + " ");
			System.out.println("���" + ":" + marks[i][2] + " ");      
		}
	}
}