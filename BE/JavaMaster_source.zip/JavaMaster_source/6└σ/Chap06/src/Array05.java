public class Array05 {
	public static void main(String[] args) {      
        		String s1 = "Java Programming";
        		String s2 = new String("Java Programming");

        		System.out.println(s1);
        		System.out.println(s2);
	}
}