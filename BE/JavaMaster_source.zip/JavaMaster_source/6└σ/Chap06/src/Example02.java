public class Example02 {
    public static void main(String[] args) {          
        int[] myArr = {10, 20, 30, 40, 50};
	
        for(int i = 0; i < myArr.length; i++) {
            System.out.println(i+ "��° ��Ұ�: " + myArr[i]);
        }      
    }
}