public class Example11 {
    public static void main(String[] args) {
            
        for (int n = 1; n <= 5; n++) {
            System.out.println("*"); 
            if (n == 2) {
                break;
            } 
        }    
 
    }
}