public class Example03 {
   public static void main(String[] args) {     
      System.out.println("Java\nProgram");   
   }
}
