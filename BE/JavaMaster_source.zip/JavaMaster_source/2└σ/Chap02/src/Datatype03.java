public class Datatype03 {
   public static void main(String[] args) {
      char ch = 'J';
      char ch2 = 'a';
      char ch3 = 'v';
      char ch4 = 'a';
      System.out.println(ch);     
      System.out.println(ch2);    
      System.out.println(ch3);
      System.out.println(ch4 );
   }
}
