public class Variable01 {
   public static void main(String[] args) {
      
      int days = 10;
      System.out.println(days); 
      
      int speed;
      speed = 20;
      System.out.println(speed);
   }

}
