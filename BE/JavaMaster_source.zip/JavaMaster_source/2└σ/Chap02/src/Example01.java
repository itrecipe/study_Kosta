public class Example01 {   
   public static void main(String[] args) {   
     final int SPEED = 20; 
     int count = 10;
     SPEED = 40;           
     count = 11;
     System.out.print("��� SPEED ����  ");  
     System.out.println(SPEED); 
     System.out.print("���� count ����  "); 
     System.out.println(count);
   }
}