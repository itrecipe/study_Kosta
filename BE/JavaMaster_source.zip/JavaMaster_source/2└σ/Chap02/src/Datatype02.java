public class Datatype02 {
   public static void main(String[] args) {
      float f = 65.20298f;
      double d = 876.765d;
      System.out.println(f);
      System.out.println(d);
    }
}
