public class Datatype04 {
   public static void main(String[] args) {
      String str = "Java";
      String str2 = "Program"
      
      System.out.println(str);    
      System.out.println(str2);
   }
}
