public class Datatype05 {
   public static void main(String[] args) {
      boolean t = true;  
      boolean f = false;  
      
      System.out.println(t);    
      System.out.println(f);
   }
}