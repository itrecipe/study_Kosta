public class InputOutput02 {
   public static void main(String[] args) {

      String myName = "ȫ�浿";
      int myAge = 20;
      
         
      System.out.print("�̸� :\t" +  myName +"\n");     
      System.out.print("���� :\t" +  myAge +"\n");     
   
    }
}
