public class InputOutput01 {
   public static void main(String[] args) {

      String myName = "ȫ�浿";
      int myAge = 20;
      
      System.out.println("�̸� : " +  myName);     
      System.out.println("���� : " +  myAge );     
   
    }
}
