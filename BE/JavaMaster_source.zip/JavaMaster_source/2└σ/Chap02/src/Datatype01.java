public class Datatype01 {
   public static void main(String[] args) {
      int a = 10;
      short s = 2;
      byte b = 6;
      long l = 125362133223L;
      System.out.println(a);
      System.out.println(s);
      System.out.println(b);
      System.out.println(l);   
    }
}
