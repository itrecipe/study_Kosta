public interface Animal02 {
	public void animalSound();

	public void animalWalk();
}
