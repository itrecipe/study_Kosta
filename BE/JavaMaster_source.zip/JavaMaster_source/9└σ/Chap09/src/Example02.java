public class Example02 {
	public static void main(String[] args) {

		Cat myCat = new Cat();

		myCat.printSound();
		myCat.displayInfo();

	}
}
