public abstract class TwoWheeler extends Vehicle {
	abstract void printType();
}