public interface Interface01 {
	public static void main(String[] args) {
		Pig myPig = new Pig();
		myPig.animalSound();
		myPig.animalWalk();
	}
}