public class Example01 {
	public static void main(String[] args) {  	
		Animal myObj = new Animal();  
	}
}