interface Papa {
	public void genderFather();

}