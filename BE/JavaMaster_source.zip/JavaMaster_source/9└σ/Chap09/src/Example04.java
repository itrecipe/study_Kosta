public class Example04 {
	public static void main(String[] args) {
		Parent myObj = new Parent(); //오류 발생
	}
}