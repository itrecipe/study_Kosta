public interface Walk {
	public void walk();
}