public abstract class FourWheeler extends Vehicle { }
