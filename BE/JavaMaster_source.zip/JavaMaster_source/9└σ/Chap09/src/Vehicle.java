public abstract class Vehicle {
	abstract void printPrice();
}
