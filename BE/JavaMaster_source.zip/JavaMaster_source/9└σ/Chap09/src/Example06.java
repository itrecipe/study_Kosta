public class Example06 {
	public static void main(String[] args) {
		Baby myBaby = new Baby();

		myBaby.genderFather();
		myBaby.genderMother();
		myBaby.printInfo();
	}
}