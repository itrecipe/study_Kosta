public class Example05 {
	public static void main(String[] args) {  		
		Father myFather = new Father();	
		myFather.printInfo();   
	}
}