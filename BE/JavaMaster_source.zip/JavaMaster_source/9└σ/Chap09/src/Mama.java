interface Mama {
	public void genderMother();
}