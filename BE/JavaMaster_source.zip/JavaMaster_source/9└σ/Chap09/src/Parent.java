public interface Parent {
	public void gender();

	public void printInfo();

	/*
	public void printInfo() { System.out.println("�θ��Դϴ�"); }
	*/
}