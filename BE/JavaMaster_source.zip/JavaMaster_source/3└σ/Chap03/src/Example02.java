public class Example02 {
   public static void main(String[] args) {
      int x = 10, y = 10;
      System.out.println(x == 10);     
      System.out.println("x�� y�� �����ϱ�? " + (x == y));
   }
}
