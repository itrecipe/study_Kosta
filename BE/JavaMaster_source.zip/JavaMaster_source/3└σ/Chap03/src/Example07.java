public class Example07 {
   public static void main(String[] args) {
      double d = 3.14;
      long l = (long)d;  
      int i = (int)l; 

      System.out.println(d);
      System.out.println(l);
      System.out.println(i);
   }
}
