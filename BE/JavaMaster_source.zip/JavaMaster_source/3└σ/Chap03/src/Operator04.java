public class Operator04 {
   public static void main(String[] args) {
      int a = 10;
      int b=20;
      int c;
      System.out.println(c = a); 	// Output =10
      System.out.println(b += a);	// Output=30
      System.out.println(b -= a);	// Output=20
      System.out.println(b *= a);	// Output=200
      System.out.println(b /= a);	// Output=2
      System.out.println(b %= a);	// Output=0
   }
}
