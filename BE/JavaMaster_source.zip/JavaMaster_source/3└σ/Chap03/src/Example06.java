public class Example06 {
   public static void main(String[] args) {
      int i = 100;
      long l = i; 
      float f = l;  
      System.out.println(i);
      System.out.println(l);
      System.out.println(f);  
   }
}
