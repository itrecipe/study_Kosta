public class Example05 {
   public static void main(String[] args) {
      int x = 10;
      System.out.println(x++);  //returns 11
      System.out.println(++x);  
      System.out.println(x--);  
      System.out.println(--x);  
   }
}
