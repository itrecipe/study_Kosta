public class Example02{  
	public static void main(String args[]){  
		Cat obj = new Cat();  
		obj.meow();  
		obj.eat();  
	}
}  