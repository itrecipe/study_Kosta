public class Example04 {  
	public static void main(String args[]) {  
		Cat objCat = new Cat(); 
		objCat.meow();
		objCat.eat();

		Dog objDog = new Dog();  
		objDog.bark();
		objDog.eat();
	}
}  