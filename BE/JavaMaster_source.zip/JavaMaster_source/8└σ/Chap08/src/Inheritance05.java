public class Inheritance05 {  
    public static void main(String[] args) {
        Child objChild = new Child();
        objChild.printDetails();
    }
}