public class Example03{  
	public static void main(String args[]){  
		Kitten objKitten = new Kitten();  
		objKitten.meow2();
		objKitten.meow();
		objKitten.eat();
		
	}
}  