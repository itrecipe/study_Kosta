public class Inheritance02{  
	public static void main(String[] args) {
    		Son objSon = new Son();
    		objSon.printDetails();

 	 }
}