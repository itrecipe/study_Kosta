public class Child2 extends Parent2{
	String name = "ȫ�浿";
     
	Child2() {    
		super();
	     	System.out.println("�ڽ� �̸� : " + name);
	}   
}
