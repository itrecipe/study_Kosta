public class Inheritance04 {  
	public static void main(String[] args) {
		SubSon objSon = new SubSon();
	    	objSon.printSon();
	    	objSon.printFather();
	   
	    	SubDaughter objDaugther = new SubDaughter();
	    	objDaugther.printDaughter();
	    	objDaugther.printFather(); 
	}
}