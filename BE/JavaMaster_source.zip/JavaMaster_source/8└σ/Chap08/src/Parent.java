public class Parent {
	String name = "ȫ���";
	    
	public void details() {    	
		System.out.println(name);
	}
}
