

public class Inheritance06{  
    public static void main(String[] args)
    {
        Child2 objChild = new Child2();
        
    }
}