public class Inheritance03{  
	public static void main(String[] args) {
    		SubSon objSon = new SubSon();
    		objSon.printSon();
    		objSon.printFather();
    		objSon.printGrandFather();

	}
}