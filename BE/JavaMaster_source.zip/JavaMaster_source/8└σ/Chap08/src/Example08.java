public class Example08{  
	public static void main(String args[]){  
		Cat myCat = new Cat();
	     	Kitten myKitten = new Kitten();
			
		myCat.sound();
	     	myKitten.sound();	
	}
}  