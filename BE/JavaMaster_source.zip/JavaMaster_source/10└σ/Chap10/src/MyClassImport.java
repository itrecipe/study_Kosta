import mypackage.MyClass;
// import mypackage.*;
import static java.lang.System.*;

public class MyClassImport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass obj = new MyClass();
		// mypackage.MyClass obj = new mypackage.MyClass();
	}

}
