package com.section03;

public class Example04 {
	public static void main(String args[]){		
		System.out.println((int)(Math.random() * 100)); 	
		System.out.println(Math.abs(-10));   
		System.out.println(Math.round(4.5));   
		System.out.println(Math.sqrt(4.0)); 		
	}
}