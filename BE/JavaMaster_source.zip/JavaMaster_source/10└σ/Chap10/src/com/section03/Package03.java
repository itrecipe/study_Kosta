package com.section03;

public class Package03 {
	public static void main(String args[]) {
		System.out.println(Math.pow(2, 2)); // 제곱
		System.out.println(Math.ceil(9.9)); // 올림
		System.out.println(Math.floor(9.9)); // 내림
		System.out.println(Math.round(9.9)); // 반올림
		System.out.println(Math.max(5, 100)); // 최댓값
		System.out.println(Math.min(5, 100)); // 최솟값
	}
}