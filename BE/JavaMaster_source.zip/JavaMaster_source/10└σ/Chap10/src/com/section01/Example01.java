package com.section01;

public class Example01 {
	public int add(int a, int b) {
		return a + b;
	}

	public static void main(String args[]) {
		Example01 obj = new Example01();
		System.out.println(obj.add(10, 20));
	}
}