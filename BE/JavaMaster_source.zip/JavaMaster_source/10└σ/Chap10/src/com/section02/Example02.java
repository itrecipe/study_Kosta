package com.section02;

import com.section01.Example01;

public class Example02 {
	public static void main(String args[]) {
		Example01 obj = new Example01();
		System.out.println(obj.add(10, 20));
	}
}