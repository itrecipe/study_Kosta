package com.section02;

import com.javamaster.mypackage.*;

public class Package01 {
	public static void main(String args[]) {
		Cat myCat = new Cat();

		myCat.eat();
		myCat.scratch();
		myCat.meow();
	}
}