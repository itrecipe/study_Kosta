package com.javamaster.mypackage;

public class Dog {
	String breed;	
	String color;
	
	
	public String bowwow() {
		return "�۸� ¢��";
	}
	
	public void run() {
		System.out.println("�޸���");
	}		
 }